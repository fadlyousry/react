import React from "react";

const useDounce = () => {
  return;
};

export default useDounce;
